//
// Created by john on 9/21/18.
//

#ifndef CS483_P1_DEBUG_H
#define CS483_P1_DEBUG_H

#define DEBUG 1

void accessdeny(char*);
void errormesg(char* mesg);
void euiderr();
void dperror(char* mesg, char* file); 

#endif //CS483_P1_DEBUG_H
